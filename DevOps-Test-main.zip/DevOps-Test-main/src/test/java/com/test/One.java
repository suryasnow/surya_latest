package com.test;

import java.util.*;

public class One {
	// private static final String BCFKS_WRONG_PASSWORD_ERROR = "MAC calculation failed";
	String message = "foo";
	private List<String> fValidateOrderedList;

	public String foo() {
		return message;
	}

	public void uncoveredMethod() {
		/*
		// Uncovered method
		*/
	}

	public void setValidateOrderedList(List<String> validateOrderedList) {
		fValidateOrderedList = validateOrderedList;
	}
}
